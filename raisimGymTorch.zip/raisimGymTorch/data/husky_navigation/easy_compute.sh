#!/bin/bash

location="2021-12-07-13-50-45"
echo ${location}
HJ=$(ls $location| grep full)

for i in $HJ; do
	 python /home/hyungjun/raisim_workspace/LearningBasedControl_FinalProject2021/raisimGymTorch/env/envs/lbc_husky/compete_script.py -w $location/$i

done

